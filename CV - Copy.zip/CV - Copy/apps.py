from django.apps import AppConfig


class CvConfig(AppConfig):
    name = 'CV'
